@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
set "code=%errorlevel%"
if not "%code%"=="0" echo Installation failed.
pause
exit /b %code%
